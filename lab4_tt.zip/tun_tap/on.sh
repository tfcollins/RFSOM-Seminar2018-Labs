echo 0x800000bc 0xffffffff > /sys/kernel/debug/iio/iio:device3/direct_reg_access
