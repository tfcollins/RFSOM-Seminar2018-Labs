#!/bin/sh

# en_dds.sh
/usr/bin/iio_reg cf-ad9361-dds-core-lpc 0x40 0x0
echo -n "cf-ad9361-dds-core-lpc reg 0x040 : "
/usr/bin/iio_reg cf-ad9361-dds-core-lpc 0x40

/usr/bin/iio_reg cf-ad9361-dds-core-lpc 0x40 0x2
echo -n "cf-ad9361-dds-core-lpc reg 0x040 : "
/usr/bin/iio_reg cf-ad9361-dds-core-lpc 0x40

/usr/bin/iio_reg cf-ad9361-dds-core-lpc 0x40 0x3
echo -n "cf-ad9361-dds-core-lpc reg 0x040 : "
/usr/bin/iio_reg cf-ad9361-dds-core-lpc 0x40

/usr/bin/iio_reg cf-ad9361-dds-core-lpc 0x4C 0x3
echo -n "cf-ad9361-dds-core-lpc reg 0x04c : "
/usr/bin/iio_reg cf-ad9361-dds-core-lpc 0x4C

/usr/bin/iio_reg cf-ad9361-dds-core-lpc 0x44 0x0
echo -n "cf-ad9361-dds-core-lpc reg 0x044 : "
/usr/bin/iio_reg cf-ad9361-dds-core-lpc 0x44

/usr/bin/iio_reg cf-ad9361-dds-core-lpc 0x48 0x0
echo -n "cf-ad9361-dds-core-lpc reg 0x048 : "
/usr/bin/iio_reg cf-ad9361-dds-core-lpc 0x48

for i in $(seq 0 3)
do
	/usr/bin/iio_reg cf-ad9361-dds-core-lpc $((0x418 + $i * 0x40)) 0x0
	echo -n "cf-ad9361-dds-core-lpc reg" $(printf "0x%x" $((0x418 + 1 * 0x40))) " : "
	/usr/bin/iio_reg cf-ad9361-dds-core-lpc $((0x418 + $i * 0x40))
done

/usr/bin/iio_reg cf-ad9361-dds-core-lpc 0x44 0x1
echo -n "cf-ad9361-dds-core-lpc reg 0x044 : "
/usr/bin/iio_reg cf-ad9361-dds-core-lpc 0x44

